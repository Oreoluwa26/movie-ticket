<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>MoviePoint</title>
	<!-- Template CSS -->
	<link rel="stylesheet" href="assets/css/style-starter.css">
	<!-- Template CSS -->
	<link href="//fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,600&display=swap"
		rel="stylesheet">
	<!-- Template CSS -->
</head>

<body>
	<!-- header -->
	<header id="site-header" class="w3l-header fixed-top">
		<!--/nav-->
		<nav class="navbar navbar-expand-lg navbar-light fill px-lg-0 py-0 px-3">
			<div class="container">
				<h1><a class="navbar-brand" href="index.php"><span class="fa fa-play icon-log"
							aria-hidden="true"></span>
						Genre </a></h1>
				<!-- if logo is image enable this   
							<a class="navbar-brand" href="#index.html">
								<img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
							</a> -->
				<button class="navbar-toggler collapsed" type="button" data-toggle="collapse"
					data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
					aria-label="Toggle navigation">
					<!-- <span class="navbar-toggler-icon"></span> -->
					<span class="fa icon-expand fa-bars"></span>
					<span class="fa icon-close fa-times"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item">
							<a class="nav-link" href="index.php">Home</a>
						</li>
		<li class="nav-item active">
								<a class="nav-link" href="genre.php">Top Movie</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="food.php">Foods & Drinks </a>
							</li>
						<li class="nav-item">
							<a class="nav-link" href="contact.php">Contact</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="./sign-up.php">Admin</a>
						</li>
					</ul>

					<!--/search-right-->
					<!--/search-right-->
					<div class="search-right">
						<a href="#search" class="btn search-hny mr-lg-3 mt-lg-0 mt-4" title="search">Search <span
								class="fa fa-search ml-3" aria-hidden="true"></span></a>
						<!-- search popup -->
						<div id="search" class="pop-overlay">
							<div class="popup">
								<form action="#" method="post" class="search-box">
									<input type="search" placeholder="Search your Keyword" name="search"
										required="required" autofocus="">
									<button type="submit" class="btn"><span class="fa fa-search"
											aria-hidden="true"></span></button>
								</form>
								<div class="browse-items">
									<h3 class="hny-title two mt-md-5 mt-4">Browse all:</h3>
									<ul class="search-items">
										<li><a href="genre.html">Action</a></li>
										<li><a href="genre.html">Drama</a></li>
										<li><a href="genre.html">Family</a></li>
										<li><a href="genre.html">Thriller</a></li>
										<li><a href="genre.html">Commedy</a></li>
										<li><a href="genre.html">Romantic</a></li>
										<li><a href="genre.html">Tv-Series</a></li>
										<li><a href="genre.html">Horror</a></li>
										<li><a href="genre.html">Action</a></li>
										<li><a href="genre.html">Drama</a></li>
										<li><a href="genre.html">Family</a></li>
										<li><a href="genre.html">Thriller</a></li>
										<li><a href="genre.html">Commedy</a></li>
										<li><a href="genre.html">Romantic</a></li>
										<li><a href="genre.html">Tv-Series</a></li>
										<li><a href="genre.html">Horror</a></li>
									</ul>
								</div>
							</div>
							<a class="close" href="#close">×</a>
						</div>
						<!-- /search popup -->
						<!--/search-right-->
					</div>


				</div>
				<!-- toggle switch for light and dark theme -->
				<div class="mobile-position">
					<nav class="navigation">
						<div class="theme-switch-wrapper">
							<label class="theme-switch" for="checkbox">
								<input type="checkbox" id="checkbox">
								<div class="mode-container">
									<i class="gg-sun"></i>
									<i class="gg-moon"></i>
								</div>
							</label>
						</div>
					</nav>
				</div>
				<!-- //toggle switch for light and dark theme -->
			</div>
		</nav>
		<!--//nav-->
	</header>
	<!-- //header -->
	<!--/breadcrumbs -->
	<div class="w3l-breadcrumbs">
		<nav id="breadcrumbs" class="breadcrumbs">
			<div class="container page-wrapper">
				<a href="index.html">Home</a> » <span class="breadcrumb_last" aria-current="page">Top Movie</span>
			</div>
		</nav>
	</div>
	<!--//breadcrumbs -->
	<!--/genre -->
	<!--grids-sec1-->
	<section class="w3l-grids">
		<div class="grids-main py-4">
			<div class="container py-lg-4">
				<div class="headerhny-title">
					<h3 class="hny-title">Popular Movies</h3>
				</div>
				<div class="owl-four owl-carousel owl-theme">
					<div class="item vhny-grid">
						<div class="box16">
							<a href="https://www.youtube.com/embed/mpOGT3GTO84">
								<figure>
									<img class="img-fluid" src="assets/images/banner1.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Rocketman</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 4min

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
						<div class="box16 mt-4">
							<a href="https://www.youtube.com/embed/Zi4LMpSDccc">
								<figure>
									<img class="img-fluid" src="assets/images/banner2.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Frozen 2</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 24mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16">
							<a href="https://www.youtube.com/embed/t433PEQGErc">
								<figure>
									<img class="img-fluid" src="assets/images/banner3.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Joker</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 55min

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
						<div class="box16 mt-4">
							<a href="https://www.youtube.com/embed/foyufD52aog">
								<figure>
									<img class="img-fluid" src="assets/images/banner4.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Aladdin</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1Hr 27mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16">
							<a href="#">
								<figure>
									<img class="img-fluid" src="assets/images/banner1.jpg" alt="">

								</figure>
								<div class="box-content">
									<h3 class="title">Rocketman</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 4min

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
						<div class="box16 mt-4">
							<a href="https://www.youtube.com/embed/Zi4LMpSDccc">
								<figure>
									<img class="img-fluid" src="assets/images/banner2.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Frozen 2</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 24min

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--//grids-sec1-->
	<!--grids-sec1-->
	<section class="w3l-grids">
		<div class="grids-main py-5">
			<div class="container py-lg-4">
				<div class="headerhny-title">
					<div class="w3l-title-grids">
						<div class="headerhny-left">
							<h3 class="hny-title">Latest Movies</h3>
						</div>
						<div class="headerhny-right text-lg-right">
							<h4><a class="show-title" href="genre.html">Show all</a></h4>
						</div>
					</div>
				</div>
				<div class="w3l-populohny-grids">
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/Zi4LMpSDccc">
								<figure>
									<img class="img-fluid" src="assets/images/m7.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Frozen 2</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 24mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/xi-1NchUqMA">
								<figure>
									<img class="img-fluid" src="assets/images/m3.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Knives Out</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 57mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
							<div id="small-dialog21" class="zoom-anim-dialog mfp-hide">
								<iframe width="1310" height="496" src="https://www.youtube.com/embed/xi-1NchUqMA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							</div>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/AST2-4db4ic" class="popup-with-zoom-anim play-view1">
								<figure>
									<img class="img-fluid" src="assets/images/m4.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Little Women</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 52mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/10VphsyJhbU">
								<figure>
									<img class="img-fluid" src="assets/images/m5.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Jumanji</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 55mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>

					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/S3vO8E2e6G0" >
								<figure>
									<img class="img-fluid" src="assets/images/m1.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Rocketman</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 4min

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/CDf_EnIhojk" >
								<figure>
									<img class="img-fluid" src="assets/images/m2.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Doctor Sleep</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 55mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/S5jiaHvx-kY">
								<figure>
									<img class="img-fluid" src="assets/images/m6.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Long Shot</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 24mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/t433PEQGErc">
								<figure>
									<img class="img-fluid" src="assets/images/m9.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Joker</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 55mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
						<a href="https://www.youtube.com/embed/NdDU_BBJW9Y" >
								<figure>
									<img class="img-fluid" src="assets/images/m11.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">The Lego</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 12mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/w7pYhpJaJW8">
								<figure>
									<img class="img-fluid" src="assets/images/m10.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Alita</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 56mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/_j5hwooOHVE">
								<figure>
									<img class="img-fluid" src="assets/images/m12.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Hustle</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 40mins

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="box16 mb-0">
							<a href="https://www.youtube.com/embed/wmiIUN-7qhE" >
								<figure>
									<img class="img-fluid" src="assets/images/m8.jpg" alt="">
								</figure>
								<div class="box-content">
									<h3 class="title">Toy Story 4</h3>
									<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 4min

										</span>

										<span class="post fa fa-heart text-right"></span>
									</h4>
								</div>
								<span class="fa fa-play video-icon" aria-hidden="true"></span>
							</a>
						</div>
					</div>

				</div>
			</div>


		</div>
	</section>
	<!--//grids-sec1-->


	<!--grids-sec2-->
	<section class="w3l-grids">
		<div class="grids-main py-4">
			<div class="container py-lg-4">
				<div class="headerhny-title">
					<h3 class="hny-title">COMING SOON</h3>
				</div>
				<div class="owl-two owl-carousel owl-theme">
					<div class="item">
						<div class="two-gridshny-grids">
							<div class="two-gridshny-left">
								<div class="box16 mb-4">
									<a href="https://www.youtube.com/embed/e4f9hOyV23k">
										<figure>
											<img class="img-fluid" src="assets/images/Butchers.jpg" alt="">
										</figure>
										<div class="box-content">
											<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 32mins

												</span>

												<span class="post fa fa-heart text-right"></span>
											</h4>
										</div>
										<span class="fa fa-play video-icon" aria-hidden="true"></span>
									</a>
								</div>
							</div>
							<div class="two-gridshny-right">
								<h3> <a class="title-gd mt-0" href="#">BUTCHERS</a></h3>

							</div>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="two-gridshny-grids">
							<div class="two-gridshny-left">
								<div class="box16 mb-4">
									<a href="https://www.youtube.com/embed/aQO16k5Vdow">
										<figure>
											<img class="img-fluid" src="assets/images/nightbooks.jpg" alt="">
										</figure>
										<div class="box-content">
											<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 49mins

												</span>

												<span class="post fa fa-heart text-right"></span>
											</h4>
										</div>
										<span class="fa fa-play video-icon" aria-hidden="true"></span>
									</a>
								</div>
							</div>
							<div class="two-gridshny-right">
								<h3> <a class="title-gd mt-0" href="#">NIGHTBOOKS</a></h3>

							</div>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="two-gridshny-grids">
							<div class="two-gridshny-left">
								<div class="box16 mb-4">
									<a href="https://www.youtube.com/embed/oyNpEolNyek">
										<figure>
											<img class="img-fluid" src="assets/images/OHDB.jpg" alt="">
										</figure>
										<div class="box-content">
											<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 22mins

												</span>

												<span class="post fa fa-heart text-right"></span>
											</h4>
										</div>
										<span class="fa fa-play video-icon" aria-hidden="true"></span>
									</a>
								</div>
							</div>
							<div class="two-gridshny-right">
								<h3> <a class="title-gd mt-0" href="#">OVER HER DEAD BODY</a></h3>

							</div>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="two-gridshny-grids">
							<div class="two-gridshny-left">
								<div class="box16 mb-4">
									<a href="https://www.youtube.com/embed/zlgco9hNJpg">
										<figure>
											<img class="img-fluid" src="assets/images/Casa.jpg" alt="">
										</figure>
										<div class="box-content">
											<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 54mins

												</span>

												<span class="post fa fa-heart text-right"></span>
											</h4>
										</div>
										<span class="fa fa-play video-icon" aria-hidden="true"></span>
									</a>
								</div>
							</div>
							<div class="two-gridshny-right">
								<h3> <a class="title-gd mt-0" href="#">CASA</a></h3>

							</div>
						</div>
					</div>
					<div class="item vhny-grid">
						<div class="two-gridshny-grids">
							<div class="two-gridshny-left">
								<div class="box16 mb-4">
									<a href="https://www.youtube.com/embed/b1WHQTbJ7vE">
										<figure>
											<img class="img-fluid" src="assets/images/shadow and bone.jpg" alt="">
										</figure>
										<div class="box-content">
											<h4> <span class="post"><span class="fa fa-clock-o"> </span> 1 Hr 34mins

												</span>

												<span class="post fa fa-heart text-right"></span>
											</h4>
										</div>
										<span class="fa fa-play video-icon" aria-hidden="true"></span>
									</a>
								</div>
							</div>
							<div class="two-gridshny-right">
								<h3> <a class="title-gd mt-0" href="#">SHADOW AND BONE</a></h3>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--grids-sec2-->
	<!--//genre -->
	<!-- footer-66 -->
	<footer class="w3l-footer">
		<section class="footer-inner-main">
			<div class="footer-hny-grids py-5">
				<div class="container py-lg-4">
					<div class="text-txt">
						<div class="right-side">
							<div class="row footer-about">
								<div class="col-md-3 col-6 footer-img mb-lg-0 mb-4">
									<a href="genre.html"><img class="img-fluid" src="assets/images/sidebar1.png"
											alt=""></a>
								</div>
								<div class="col-md-3 col-6 footer-img mb-lg-0 mb-4">
									<a href="genre.html"><img class="img-fluid" src="assets/images/sidebar2.png"
											alt=""></a>
								</div>
								<div class="col-md-3 col-6 footer-img mb-lg-0 mb-4">
									<a href="genre.html"><img class="img-fluid" src="assets/images/sidebar3.png"
											alt=""></a>
								</div>
								<div class="col-md-3 col-6 footer-img mb-lg-0 mb-4">
									<a href="genre.html"><img class="img-fluid" src="assets/images/sidebar4.png"
											alt=""></a>
								</div>
							</div>
							<div class="row footer-links">


								<div class="col-md-3 col-sm-6 sub-two-right mt-5">
									<h6>Movies</h6>
									<ul>
										<li><a href="#">Movies</a></li>
										<li><a href="#">Videos</a></li>
										<li><a href="#">English Movies</a></li>
										<li><a href="#">Tailor</a></li>
										<li><a href="#">Upcoming Movies</a></li>
										<li><a href="contact.html">Contact Us</a></li>
									</ul>
								</div>
								<div class="col-md-3 col-sm-6 sub-two-right mt-5">
									<h6>Information</h6>
									<ul>
										<li><a href="index.html">Home</a> </li>
										<li><a href="about.html">About</a> </li>
										<li><a href="#">Tv Series</a> </li>
										<li><a href="#">Blogs</a> </li>
										<li><a href="#">Login</a></li>
										<li><a href="contact.html">Contact</a></li>
									</ul>
								</div>
								<div class="col-md-3 col-sm-6 sub-two-right mt-5">
									<h6>Locations</h6>
									<ul>
										<li><a href="genre.html">Asia</a></li>
										<li><a href="genre.html">France</a></li>
										<li><a href="genre.html">Taiwan</a></li>
										<li><a href="genre.html">United States</a></li>
										<li><a href="genre.html">Korea</a></li>
										<li><a href="genre.html">United Kingdom</a></li>
									</ul>
								</div>
								<div class="col-md-3 col-sm-6 sub-two-right mt-5">
									<h6>Newsletter</h6>
									<form action="#" class="subscribe mb-3" method="post">
										<input type="email" name="email" placeholder="Your Email Address" required="">
										<button><span class="fa fa-envelope-o"></span></button>
									</form>
									<p>Enter your email and receive the latest news, updates and special offers from us.
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			</div>
			<div class="below-section">
				<div class="container">
					<div class="copyright-footer">
						<div class="columns text-lg-left">
							<p>&copy; 2022 MoviePoint. All rights reserved | Designed by MoviePoint</p>
						</div>

						<ul class="social text-lg-right">
							<li><a href="#facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
							</li>
							<li><a href="#linkedin"><span class="fa fa-linkedin" aria-hidden="true"></span></a>
							</li>
							<li><a href="#twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
							</li>
							<li><a href="#google"><span class="fa fa-google-plus" aria-hidden="true"></span></a>
							</li>

						</ul>
					</div>
				</div>
			</div>
			<!-- copyright -->
			<!-- move top -->
			<button onclick="topFunction()" id="movetop" title="Go to top">
				<span class="fa fa-arrow-up" aria-hidden="true"></span>
			</button>
			<script>
				// When the user scrolls down 20px from the top of the document, show the button
				window.onscroll = function () {
					scrollFunction()
				};

				function scrollFunction() {
					if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
						document.getElementById("movetop").style.display = "block";
					} else {
						document.getElementById("movetop").style.display = "none";
					}
				}

				// When the user clicks on the button, scroll to the top of the document
				function topFunction() {
					document.body.scrollTop = 0;
					document.documentElement.scrollTop = 0;
				}
			</script>
			<!-- /move top -->

		</section>
	</footer>
	<!--//footer-66 -->
</body>

</html>
<script src="assets/js/jquery-3.3.1.min.js"></script>
<!--/theme-change-->
<script src="assets/js/theme-change.js"></script>
<!-- //theme-change-->
<script src="assets/js/owl.carousel.js"></script>
<script>
	$(document).ready(function () {
		$('.owl-four').owlCarousel({
			loop: true,
			margin: 20,
			nav: false,
			responsiveClass: true,
			autoplay: false,
			autoplayTimeout: 5000,
			autoplaySpeed: 1000,
			autoplayHoverPause: false,
			responsive: {
				0: {
					items: 1,
					nav: false
				},
				480: {
					items: 2,
					nav: true
				},
				667: {
					items: 2,
					nav: true
				},
				1000: {
					items: 2,
					nav: true
				}
			}
		})
	})
</script>
<script>
	$(document).ready(function () {
		$('.owl-two').owlCarousel({
			loop: true,
			margin: 40,
			nav: false,
			responsiveClass: true,
			autoplay: true,
			autoplayTimeout: 5000,
			autoplaySpeed: 1000,
			autoplayHoverPause: false,
			responsive: {
				0: {
					items: 1,
					nav: false
				},
				480: {
					items: 2,
					nav: true
				},
				667: {
					items: 2,
					margin: 20,
					nav: true
				},
				1000: {
					items: 3,
					nav: true
				}
			}
		})
	})
</script>
<!-- //script -->
<!-- //script -->
<!-- script for owlcarousel -->
<!-- disable body scroll which navbar is in active -->
<script>
	$(function () {
		$('.navbar-toggler').click(function () {
			$('body').toggleClass('noscroll');
		})
	});
</script>
<!-- disable body scroll which navbar is in active -->

<!--/MENU-JS-->
<script>
	$(window).on("scroll", function () {
		var scroll = $(window).scrollTop();

		if (scroll >= 80) {
			$("#site-header").addClass("nav-fixed");
		} else {
			$("#site-header").removeClass("nav-fixed");
		}
	});

	//Main navigation Active Class Add Remove
	$(".navbar-toggler").on("click", function () {
		$("header").toggleClass("active");
	});
	$(document).on("ready", function () {
		if ($(window).width() > 991) {
			$("header").removeClass("active");
		}
		$(window).on("resize", function () {
			if ($(window).width() > 991) {
				$("header").removeClass("active");
			}
		});
	});
</script>
<!--//MENU-JS-->
<script src="assets/js/bootstrap.min.js"></script>